/*
    This date string is hereby put into the public domain.
    Copyrighting this is crazy. It's just a date string
    and is modified from time to time.
*/

#define DW_VERSION_DATE_STR " 2018-08-09 08:32:59-07:00  "
